from .core import * 
from .terminal import cli

__version__ = '0.2.5'

